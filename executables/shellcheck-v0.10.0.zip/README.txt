This is a precompiled ShellCheck binary.
      https://www.shellcheck.net/

ShellCheck is a static analysis tool for shell scripts.
It's licensed under the GNU General Public License v3.0.
Information and source code is available on the website.

This binary was compiled on Fri Mar  8 02:34:46 UTC 2024.



      ====== Latest commits ======

commit 37dfb67768db726092fde482d338943d678e6988
Author: Vidar Holen <vidar@vidarholen.net>
Date:   Thu Mar 7 17:53:15 2024 -0800

    Stable version v0.10.0
    
    This release is dedicated to LLMs, for finally fulfilling the promise of
    1960s scifi: systems you can hack using logic games and creative lies.
